import hashlib
from cryptography.hazmat.primitives import serialization
from cryptography.x509 import load_pem_x509_certificate
import base64

def calculate_thumbprint(pem_data: str, hash_algorithm: str = 'SHA-1') -> str:
    """
    Calculate certificate thumbprint from PEM-encoded data.
    Defaults to SHA-1 (common for MTLS), but supports SHA-256.
    """
    # Load certificate from PEM
    cert = load_pem_x509_certificate(pem_data.encode('utf-8'))
    
    # Get DER-encoded bytes
    der_bytes = cert.public_bytes(encoding=serialization.Encoding.DER)
    
    # Calculate hash
    if hash_algorithm.upper() == 'SHA-1':
        digest = hashlib.sha1(der_bytes).digest()
    elif hash_algorithm.upper() == 'SHA-256':
        digest = hashlib.sha256(der_bytes).digest()
    else:
        raise ValueError(f"Unsupported hash algorithm: {hash_algorithm}")
    
    # Convert to hex string (uppercase without colons)
    return digest.hex().upper()

def lambda_handler(event, context):
    try:
        # Extract client certificate from API Gateway event
        client_cert_pem = event['requestContext']['identity']['clientCert']['clientCertPem']
        
        # Calculate thumbprint (default SHA-1)
        thumbprint = calculate_thumbprint(client_cert_pem)
        
        return {
            "principalId": "mtls-user",
            "policyDocument": {
                "Version": "2012-10-17",
                "Statement": [{
                    "Action": "execute-api:Invoke",
                    "Effect": "Allow",
                    "Resource": event['methodArn']
                }]
            },
            "context": {
                "certThumbprint": thumbprint
            }
        }
    
    except KeyError:
        return {
            "principalId": "anonymous",
            "policyDocument": {
                "Version": "2012-10-17",
                "Statement": [{
                    "Action": "execute-api:Invoke",
                    "Effect": "Deny",
                    "Resource": event['methodArn']
                }]
            },
            "context": {}
        }
    
    except Exception as e:
        print(f"Error processing certificate: {str(e)}")
        raise

